# Electricity-Bill-Generation-System

This Project is Done using PHP,MYSQL,HTML,CSS,BOOTSTRAP

If you want to run this project on your system ,Your system needs xampp or wampp server.

In admin portal , 
USER : admin
PASS : admin

And you have to import the given sql file in your mysql.
